package example;

public class ThreadExample {

	public static void main(String[] args) throws InterruptedException {

		Thread t = Thread.currentThread();
		System.out.println(t); //[name-thread,priority-5,name-function]
		t.setName("Rename");
		System.out.println(t); 
		
		System.out.println(t.isAlive());
		System.out.println(t.getPriority());
		System.out.println(t.getName());
		System.out.println(t.getId());
		
		CustomThread ct = new CustomThread("NewThread");
		
		///
		for(int i=1; i<=5;i++) {
			System.out.println("index ="+i);
			Thread.sleep(100);
		}
		
		
	}

}
