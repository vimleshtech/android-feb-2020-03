package example;

public class CustomThread implements Runnable {

	Thread nt=null;
	CustomThread(String name){
		
		this.nt = new Thread(this,name);
		this.nt.start(); //
	}
	
	@Override
	public void run() {
	
		for(int j=11; j<=15; j++) {
			try {
				System.out.println(this.nt.getName()+":"+j);
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
