package example;


//register or load the driver or connector 
import java.sql.DriverManager;
//establish the connection from code to backend
import java.sql.Connection;

//create sql command and statement and execute 
import java.sql.PreparedStatement;

//store the sql command output 
import java.sql.ResultSet;

public class JDBCExample {

	public static void saveData(int id, String name) {


		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/myapp","root","root");
			
			PreparedStatement ps = con.prepareStatement("insert into users(uid,name) values(?,?);");
			ps.setInt(1, id);
			ps.setString(2,name);
			
			int r = ps.executeUpdate(); //insert, update, delete
			
			System.out.println(r+" has insered");
			

		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
	}
	public static void main(String[] args) {


		
		try {
			saveData(11, "rahul");
			saveData(1001, "monika");
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/myapp","root","root");
			
			PreparedStatement ps = con.prepareStatement("select * from users;");
			
		
			//select
			ResultSet rs = ps.executeQuery(); //run the sql command and fetch the result
			
			while(rs.next()) {
				System.out.println(rs.getString(1)+rs.getString(2));
			}
			
			
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}

	}

}
